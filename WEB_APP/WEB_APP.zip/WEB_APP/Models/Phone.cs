﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_APP.Models
{
    public class Phone{
        public int ID { get; set; }
        public String Name { get; set; }
        public String Model { get; set; }
        public decimal Price { get; set; }
        static List<Phone> Phonelist = null;
        static Phone()  {
            Phonelist = new List<Phone>()
            {
                new Phone()
                {
                ID = 1,
                Name = "VIVO",
                Model = "Z1x",
                Price = 15000
                }
            };
        }
        public static List<Phone> SelectCarList()
        {
            return Phonelist;
        }
    }
}
